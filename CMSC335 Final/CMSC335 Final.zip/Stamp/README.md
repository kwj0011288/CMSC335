

Submitted by: Wonjae Kim (UID: 117283365)

Group Members: Kyumin Hwang(UID: 119134092), Hyeonjin Choi(UID: 119055663),Wonjae Kim(UID: 117283365)

App Description: This program is to search and save favorite classes or previous classes from Professor 
Nelson, Maksym, and Cliff. 

YouTube Video Link: https://youtu.be/a4oiI52Rhf4
Deploy Link: https://stamp-d2xv.onrender.com

APIs: Beta umd Professor API (https://beta.umd.io/#operation/getProfessors)

Contact Email: 
Wonjae Kim: wkim1128@umd.edu
Kyumin Hwang: davidhwang1020@gmail.com
Hyeonjin Choi: chlguswls6270@gmail.com
        

