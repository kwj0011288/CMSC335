async function load_from_api() {
    let url = "https://api.umd.io/v1/professors";
    let results = [];
    let page = 1;
    let per_page = 100; 
    let hasMore = true;

    while (hasMore) {
        console.log("Fetching page:", page); 
        try {
            let response = await fetch(`${url}?page=${page}&per_page=${per_page}`);
            if (!response.ok) {
                throw new Error('Failed to fetch data: ' + response.statusText);
            }
            let data = await response.json();
            results = results.concat(data);
            page++;
            hasMore = data.length === per_page; 
        } catch (error) {
            console.error("Error fetching data:", error);
            break;
        }
    }

    return results;
}

module.exports = { load_from_api };