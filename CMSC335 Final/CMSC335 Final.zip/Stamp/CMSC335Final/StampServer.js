const { load_from_api } = require("./professorList");
const express = require("express");
const fs = require('fs');
const app = express();
const path = require("path");
const localPath = path.resolve(__dirname, "public/templates");
require("dotenv").config({ path: path.resolve(__dirname, 'credentialsDontPost/.env') })
const bodyParser = require("body-parser");
const { MongoClient, ServerApiVersion } = require('mongodb');
const portNumber = 5001;

app.set("views", path.resolve(__dirname, "templates"));
app.set("view engine", "ejs");

app.use(express.static(path.join(__dirname, "CMSC335 FINAL")));

const databaseAndCollection = { db: "Courses", collection: "CMSC" };
const uri = process.env.MONGO_CONNECTION_STRING;
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true, serverApi: ServerApiVersion.v1 });

async function find_professor(name) {
  const startTime = new Date();
  let professors = await load_from_api();
  const endTime = new Date();
  let filteredProfessors = professors.filter(professor => professor.name && professor.name.includes(name));
  let result = filteredProfessors
    .map(professor => professor.taught.map(course => course.course_id))
    .reduce((acc, courseList) => acc.concat(courseList), []);

  result = [...new Set(result)];

  console.log(`Courses taught by ${name}:`, result);

  const timeElapsed = endTime - startTime;
  console.log("Time elapsed (in milliseconds):", timeElapsed);
  return result;
}
app.use(bodyParser.urlencoded({ extended: false }));

app.get("/", async (request, response) => {

  response.render("index.ejs");
});
app.get("/selectCoursesMax", async (request, response) => {
  let courseList = await find_professor("Maksym Morawski");

  console.log(courseList);

  response.render("selectCoursesMax", { name: "Max's ", courseList: courseList });
})

app.get("/selectCoursesCliff", async (request, response) => {
  let courseList = await find_professor("Cliff Bakalian");

  console.log(courseList);

  response.render("selectCoursesMax", { name: "Cliff's ", courseList: courseList });
});

app.get("/selectCoursesNelson", async (request, response) => {
  let courseList = await find_professor("Nelson Padua-Perez");

  console.log(courseList);

  response.render("selectCoursesMax", { courseList: courseList, name: "Nelson's " });
});

app.post("/processClass", async (request, response) => {

  let courses = request.body.courses;
  if (typeof (courses) === "string") {
    courses = [courses];
  }

  let send = {
    name: request.body.name,
    email: request.body.email,
    courses: courses
  };

  const result = await client.db(databaseAndCollection.db).collection(databaseAndCollection.collection).insertOne(send);

  response.render("processClass.ejs", send);
});

app.get("/checkPreviousCourses", (request, response) => {
  response.render("checkPreviousCourses.ejs");
})

app.post("/checkPreviousCourses", async (request, response) => {
  let filter = { email: request.body.email };
  
  let result = await client.db(databaseAndCollection.db)
      .collection(databaseAndCollection.collection)
      .findOne(filter);

  if (result) {
    let register = Array.isArray(result.courses) ? result.courses : [result.courses];
    let name = result.name;
    let email = result.email;

    response.render("processPreviousCourses.ejs", { name, email, register });
  } else {
    response.render("processPreviousCourses.ejs", {
      name: "WHO ARE YOU?",
      email: "You did not type correct Email",
      register: ["Invalid Data"]  
    });
  }
});


/* Terminal */
const prompt = "Stop to shutdown the server: ";
process.stdin.setEncoding("utf8");

process.stdin.on("readable", function () {
  const dataInput = process.stdin.read();
  if (dataInput !== null) {
    const command = dataInput.trim();
    if (command === "stop") {
      console.log("Shutting down the server");
      process.exit(0);
    }
    process.stdout.write(prompt);
    process.stdin.resume();
  }
});

app.listen(portNumber, () => {
  console.log(`WebServer started and running at http://localhost:${portNumber}`);
  process.stdout.write(prompt);
});
